# elk-dockerimage.png
Multi node elk cluster using docker


Read following article

https://www.elastic.co/guide/en/elasticsearch/reference/current/docker.html
https://quoeamaster.medium.com/deploying-metricbeat-side-by-side-with-elasticsearch-in-docker-42c769d95be

https://github.com/deviantony/docker-elk


Free API
https://apipheny.io/free-api/#finance-apis